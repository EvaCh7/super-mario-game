<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="Zombie" tilewidth="16" tileheight="16" tilecount="624" columns="26">
 <image source="../sprites/Zombie.png" width="416" height="384"/>
</tileset>
