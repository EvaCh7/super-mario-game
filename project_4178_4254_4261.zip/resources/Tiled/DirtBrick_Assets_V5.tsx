<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="DirtBrick_Assets_V5" tilewidth="16" tileheight="16" tilecount="320" columns="20">
 <image source="../map/map_one/DirtBrick_Assets_V5.png" width="328" height="257"/>
</tileset>
