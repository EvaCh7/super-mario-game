<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="slime" tilewidth="16" tileheight="16" tilecount="150" columns="15">
 <image source="../sprites/slime.png" width="240" height="160"/>
</tileset>
