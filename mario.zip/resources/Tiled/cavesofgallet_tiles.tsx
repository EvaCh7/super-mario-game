<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="cavesofgallet_tiles" tilewidth="8" tileheight="8" tilecount="96" columns="8">
 <image source="../map/map_one/cavesofgallet_tiles.png" width="64" height="96"/>
</tileset>
