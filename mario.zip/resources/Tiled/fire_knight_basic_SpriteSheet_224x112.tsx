<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="fire_knight_basic_SpriteSheet_224x112" tilewidth="224" tileheight="112" tilecount="364" columns="28">
 <image source="../../../../../Documents/Elementals_fire_knight_basic_v1.0/fire_knight_basic_SpriteSheet_224x112.png" width="6272" height="1456"/>
 <tile id="1">
  <objectgroup draworder="index" id="4">
   <object id="7" x="114.25" y="74.5" width="0.25"/>
   <object id="9" x="109.75" y="67" width="8.5" height="14.5"/>
   <object id="10" x="67.25" y="104.5" width="7" height="6.5"/>
   <object id="11" x="76.25" y="101.75" width="7.5" height="8.25"/>
   <object id="12" x="72.5" y="104" width="9" height="8.5"/>
   <object id="13" x="82.25" y="99" width="10.5" height="10"/>
   <object id="14" x="83.25" y="96.25" width="11" height="4.75"/>
   <object id="15" x="94" y="90.5" width="9" height="8.75"/>
   <object id="16" x="94.75" y="92" width="8.5" height="7.75"/>
   <object id="17" x="87.25" y="89.75" width="15.25" height="13"/>
   <object id="18" x="99.5" y="85.25" width="11" height="10.5"/>
   <object id="19" x="104.5" y="78.25" width="10.25" height="10"/>
   <object id="20" x="103" y="71.5" width="10.25" height="10.25"/>
   <object id="21" x="104" y="78" width="8" height="12"/>
   <object id="22" x="114.5" y="75.25" width="11" height="10.25"/>
   <object id="23" x="107.75" y="84" width="11.75" height="7"/>
   <object id="24" x="114.5" y="90.25" width="10.75" height="10"/>
   <object id="25" x="113.75" y="97.25" width="12.25" height="9.5"/>
   <object id="26" x="121.25" y="106.75" width="6.25" height="5.75"/>
   <object id="27" x="97.5" y="100.5" width="11" height="10"/>
   <object id="28" x="103.5" y="93.25" width="9" height="9.75"/>
   <object id="29" x="110.5" y="88.5" width="6.5" height="6.25"/>
   <object id="30" x="111.5" y="93" width="4" height="9.5"/>
   <object id="31" x="80.5" y="97.25" width="5.25" height="6.25"/>
   <object id="32" x="68.25" y="103.75" width="6.75" height="5"/>
   <object id="33" x="63.25" y="52.75" width="77.25" height="65.5"/>
  </objectgroup>
 </tile>
</tileset>
