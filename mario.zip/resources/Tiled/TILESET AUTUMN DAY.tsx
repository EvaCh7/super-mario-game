<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="TILESET AUTUMN DAY" tilewidth="16" tileheight="16" tilecount="32" columns="8">
 <image source="../../../../../Documents/TINY FOREST 2.0 - ADDED WATERFALL/TILESET AUTUMN DAY.png" width="128" height="64"/>
</tileset>
