<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="herochar" tilewidth="16" tileheight="16" tilecount="120" columns="8">
 <image source="../sprites/herochar.png" width="128" height="240"/>
</tileset>
