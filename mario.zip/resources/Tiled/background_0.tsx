<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="background_0" tilewidth="16" tileheight="16" tilecount="198" columns="18">
 <image source="../map/map_one/background_0.png" width="288" height="180"/>
</tileset>
