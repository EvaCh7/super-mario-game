#ifndef __JSON_H__
#define __JSON_H__

#include <nlohmann/json.hpp>

typedef nlohmann::json json;

#endif