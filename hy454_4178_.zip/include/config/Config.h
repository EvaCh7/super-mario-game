#ifndef __CONFIG_H__
#define __CONFIG_H__

#include <iostream>
#include "tools/json.h"

class Config {
private:
	


public:
	
	static json GetConfig(std::string path);


};

#endif